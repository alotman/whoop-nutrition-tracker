# WHOOP + Nutrition Tracker (GitHub Ready)

Static single-page app. Deploy on Vercel via Git import.

## Deploy to Vercel
1. Create a new GitHub repo (e.g., `whoop-nutrition-tracker`).
2. Add `index.html` and commit.
3. On Vercel: New Project → Continue with GitHub → select repo.
   - Framework Preset: **Other**
   - Build Command: *(leave blank)*
   - Output Directory: **.**
4. Deploy.

## Local Use
Open `index.html` in your browser.
